from . import routes_setup
from . import routes_trabajadores
from . import routes_qr
# los demás que tengas
