#!/usr/bin/env python3
"""
Print Agent (FastAPI) - minimal, robust, cross-platform-friendly agent.

Endpoints:
- GET  /health
- GET  /printers          (requires X-Agent-Token)
- POST /jobs              (requires X-Agent-Token) -> queues job + worker processes
- GET  /jobs/{job_id}     (requires X-Agent-Token)
Config via ENV: AGENT_TOKEN, AGENT_ID, PRINTERS_JSON, DB_PATH
"""
import os
import json
import logging
import base64
import uuid
import socket
import subprocess
import sqlite3
import time
import threading
from datetime import datetime
from typing import Any, Dict, List, Optional

from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel

# -----------------------------
# Configuration (env)
# -----------------------------
AGENT_TOKEN = os.getenv("AGENT_TOKEN", "change-me")
AGENT_ID = os.getenv("AGENT_ID", "agent-unknown")
PRINTERS_JSON = os.getenv("PRINTERS_JSON", "[]")  # JSON list of printer configs
DB_PATH = os.getenv("DB_PATH", "print_agent_jobs.db")
WORKER_POLL_INTERVAL = float(os.getenv("WORKER_POLL_INTERVAL", "2"))  # seconds
MAX_RETRIES = int(os.getenv("MAX_RETRIES", "5"))
RETRY_BACKOFF_BASE = float(os.getenv("RETRY_BACKOFF_BASE", "2"))  # seconds

# -----------------------------
# Logging
# -----------------------------
logging.basicConfig(level=os.getenv("LOG_LEVEL", "INFO"))
logger = logging.getLogger("print_agent")

# -----------------------------
# Load printers
# Each printer: {"name": "zebra1", "type": "network", "host": "...", "port":9100}
# or {"name": "office_lp", "type":"command", "cmd": ["lp", "-d", "Zebra_TP"]}
# -----------------------------
try:
    PRINTERS: List[Dict[str, Any]] = json.loads(PRINTERS_JSON) if PRINTERS_JSON else []
    if not isinstance(PRINTERS, list):
        logger.warning("PRINTERS_JSON not a list; using empty list")
        PRINTERS = []
except Exception as e:
    logger.exception("Failed to parse PRINTERS_JSON; using empty list: %s", e)
    PRINTERS = []

PRINTER_MAP = {p["name"]: p for p in PRINTERS if "name" in p}

# -----------------------------
# DB helpers (SQLite)
# -----------------------------
def init_db(path: str):
    conn = sqlite3.connect(path, check_same_thread=False)
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS jobs (
            id TEXT PRIMARY KEY,
            printer TEXT NOT NULL,
            payload BLOB NOT NULL,
            copies INTEGER NOT NULL DEFAULT 1,
            status TEXT NOT NULL,
            attempts INTEGER NOT NULL DEFAULT 0,
            last_error TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        )
        """
    )
    conn.commit()
    return conn

_db_conn = init_db(DB_PATH)

def db_insert_job(job_id: str, printer: str, payload: bytes, copies: int):
    now = datetime.utcnow().isoformat()
    _db_conn.execute(
        "INSERT INTO jobs (id, printer, payload, copies, status, attempts, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
        (job_id, printer, payload, copies, "queued", 0, now, now),
    )
    _db_conn.commit()

def db_fetch_one_queued():
    cur = _db_conn.execute("SELECT id FROM jobs WHERE status = 'queued' ORDER BY created_at LIMIT 1")
    row = cur.fetchone()
    if not row:
        return None
    job_id = row[0]
    now = datetime.utcnow().isoformat()
    res = _db_conn.execute(
        "UPDATE jobs SET status = 'processing', attempts = attempts + 1, updated_at = ? WHERE id = ? AND status = 'queued'",
        (now, job_id),
    )
    _db_conn.commit()
    if res.rowcount == 1:
        cur = _db_conn.execute("SELECT id, printer, payload, copies, attempts FROM jobs WHERE id = ?", (job_id,))
        r = cur.fetchone()
        if r:
            return {"id": r[0], "printer": r[1], "payload": r[2], "copies": r[3], "attempts": r[4]}
    return None

def db_update_job_done(job_id: str):
    now = datetime.utcnow().isoformat()
    _db_conn.execute("UPDATE jobs SET status = 'done', updated_at = ?, last_error = NULL WHERE id = ?", (now, job_id))
    _db_conn.commit()

def db_update_job_failed(job_id: str, error_msg: str):
    now = datetime.utcnow().isoformat()
    _db_conn.execute(
        "UPDATE jobs SET status = 'failed', last_error = ?, updated_at = ? WHERE id = ?",
        (error_msg[:1000], now, job_id),
    )
    _db_conn.commit()

def db_requeue_with_backoff(job_id: str, attempts: int, error_msg: str):
    if attempts >= MAX_RETRIES:
        db_update_job_failed(job_id, f"Max retries reached: {error_msg}")
        return
    now = datetime.utcnow().isoformat()
    _db_conn.execute(
        "UPDATE jobs SET status = 'queued', last_error = ?, updated_at = ? WHERE id = ?",
        (error_msg[:1000], now, job_id),
    )
    _db_conn.commit()

def db_get_job(job_id: str):
    cur = _db_conn.execute("SELECT id, printer, attempts, status, last_error, created_at, updated_at FROM jobs WHERE id = ?", (job_id,))
    r = cur.fetchone()
    if not r:
        return None
    return {
        "id": r[0],
        "printer": r[1],
        "attempts": r[2],
        "status": r[3],
        "last_error": r[4],
        "created_at": r[5],
        "updated_at": r[6],
    }

# -----------------------------
# Printing backends
# -----------------------------
def send_to_network_printer(host: str, port: int, data: bytes, timeout: int = 10):
    try:
        with socket.create_connection((host, int(port)), timeout=timeout) as s:
            s.sendall(data)
    except Exception as e:
        raise RuntimeError(f"Network send error to {host}:{port} -> {e}")

def send_to_command_printer(cmd: List[str], data: bytes, timeout: int = 30):
    try:
        proc = subprocess.run(cmd, input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=timeout)
        if proc.returncode != 0:
            stderr = proc.stderr.decode(errors="ignore")
            raise RuntimeError(f"Command failed: {stderr}")
    except Exception as e:
        raise RuntimeError(f"Command execution error: {e}")

# -----------------------------
# Worker thread
# -----------------------------
_worker_stop = threading.Event()

def worker_loop(poll_interval: float):
    logger.info("Worker started, polling every %s seconds", poll_interval)
    while not _worker_stop.is_set():
        try:
            job = db_fetch_one_queued()
            if not job:
                time.sleep(poll_interval)
                continue

            job_id = job["id"]
            printer_name = job["printer"]
            payload = job["payload"]
            copies = int(job["copies"])
            attempts = int(job["attempts"])

            logger.info("Processing job %s -> printer=%s attempts=%s", job_id, printer_name, attempts)

            p = PRINTER_MAP.get(printer_name)
            if not p:
                err = f"Printer config '{printer_name}' not found"
                logger.error(err)
                db_update_job_failed(job_id)
                continue

            try:
                if p.get("type") == "network":
                    host = p.get("host")
                    port = p.get("port", 9100)
                    if not host:
                        raise RuntimeError("Printer config missing host")
                    for i in range(copies):
                        send_to_network_printer(host, port, payload)
                elif p.get("type") == "command":
                    cmd = p.get("cmd")
                    if isinstance(cmd, str):
                        cmd_list = cmd.split()
                    else:
                        cmd_list = cmd
                    send_to_command_printer(cmd_list, payload)
                else:
                    raise RuntimeError(f"Unsupported printer type: {p.get('type')}")
            except Exception as e:
                logger.exception("Job %s printing error: %s", job_id, e)
                db_requeue_with_backoff(job_id, attempts, str(e))
                time.sleep(min(10, RETRY_BACKOFF_BASE ** attempts))
                continue

            db_update_job_done(job_id)
            logger.info("Job %s done", job_id)

        except Exception as e:
            logger.exception("Worker unexpected error: %s", e)
            time.sleep(1)

# -----------------------------
# FastAPI app and endpoints
# -----------------------------
app = FastAPI(title="Print Agent")

class JobRequest(BaseModel):
    printer: str
    raw_base64: Optional[str] = None
    raw_text: Optional[str] = None
    copies: int = 1
    client_job_id: Optional[str] = None

def require_token(request: Request):
    token = request.headers.get("X-Agent-Token")
    if not token or token != AGENT_TOKEN:
        raise HTTPException(status_code=401, detail="Invalid agent token")

@app.on_event("startup")
def on_startup():
    t = threading.Thread(target=worker_loop, args=(WORKER_POLL_INTERVAL,), daemon=True)
    t.start()
    logger.info("Agent %s starting. Printers: %s", AGENT_ID, list(PRINTER_MAP.keys()))

@app.on_event("shutdown")
def on_shutdown():
    _worker_stop.set()
    logger.info("Agent shutting down")

@app.get("/health")
def health():
    return {"ok": True, "agent_id": AGENT_ID, "printers": list(PRINTER_MAP.keys())}

@app.get("/printers")
def list_printers(request: Request):
    require_token(request)
    result = []
    for p in PRINTERS:
        result.append({k: v for k, v in p.items() if k in ("name", "type", "host", "port")})
    return result

@app.post("/jobs")
def post_job(job: JobRequest, request: Request):
    require_token(request)
    if job.printer not in PRINTER_MAP:
        raise HTTPException(status_code=404, detail=f"Printer '{job.printer}' not found")
    if job.raw_base64:
        try:
            payload = base64.b64decode(job.raw_base64)
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"Invalid base64 payload: {e}")
    elif job.raw_text is not None:
        payload = job.raw_text.encode("utf-8")
    else:
        raise HTTPException(status_code=400, detail="Provide raw_base64 or raw_text")
    if job.copies < 1 or job.copies > 100:
        raise HTTPException(status_code=400, detail="copies must be between 1 and 100")
    job_id = job.client_job_id or str(uuid.uuid4())
    try:
        db_insert_job(job_id, job.printer, payload, int(job.copies))
    except Exception as e:
        logger.exception("Failed inserting job: %s", e)
        raise HTTPException(status_code=500, detail="Failed to persist job")
    logger.info("Job %s queued for printer %s (copies=%s)", job_id, job.printer, job.copies)
    return {"job_id": job_id, "status": "queued"}

@app.get("/jobs/{job_id}")
def get_job(job_id: str, request: Request):
    require_token(request)
    j = db_get_job(job_id)
    if not j:
        raise HTTPException(status_code=404, detail="Job not found")
    return j