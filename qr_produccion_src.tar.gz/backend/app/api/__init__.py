#from . import routes_setup
#from . import routes_trabajadores
#from . import routes_qr
#from . import routes_scans
#from . import routes_reports


# los demás que tengas
