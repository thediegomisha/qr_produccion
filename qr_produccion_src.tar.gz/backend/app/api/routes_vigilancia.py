from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field
from datetime import date, datetime
import requests

from app.services.reniec import consultar_dni_fullname

router = APIRouter(prefix="/vigilancia", tags=["vigilancia"])


# ======================================================
# Helpers
# ======================================================
def _only_digits(s: str) -> str:
    return "".join(c for c in (s or "") if c.isdigit())


def norm_persona_from_service(raw) -> tuple[str, str, str]:
    """
    Normaliza distintos formatos posibles del servicio externo (PeruDevs/RENIEC-like).

    Soporta:
    - {"estado": true, "resultado": {...}}
    - {...} directo
    - claves snake_case / camelCase
    - apellidos juntos en "apellidos" o "apellido"
    - fallback con "nombre_completo"
    """
    if isinstance(raw, dict):
        data = raw.get("resultado")
        if not isinstance(data, dict):
            data = raw
    else:
        data = {}

    nombres = (data.get("nombres") or data.get("nombre") or data.get("nombres_completos") or "").strip()

    ap_pat = (data.get("apellido_paterno") or data.get("apellidoPaterno") or data.get("ap_paterno") or "").strip()
    ap_mat = (data.get("apellido_materno") or data.get("apellidoMaterno") or data.get("ap_materno") or "").strip()

    apellidos = (data.get("apellidos") or data.get("apellido") or "").strip()
    if (not ap_pat and not ap_mat) and apellidos:
        partes = apellidos.split()
        if len(partes) == 1:
            ap_pat = partes[0]
        elif len(partes) >= 2:
            ap_pat = partes[0]
            ap_mat = " ".join(partes[1:])

    nombre_completo = (data.get("nombre_completo") or data.get("nombreCompleto") or "").strip()
    if nombre_completo and (not ap_pat or not ap_mat or not nombres):
        parts = nombre_completo.split()
        if len(parts) >= 3:
            ap_pat = ap_pat or parts[-2]
            ap_mat = ap_mat or parts[-1]
            nombres = nombres or " ".join(parts[:-2])

    return nombres, ap_pat, ap_mat


# ======================================================
# DTOs
# ======================================================
class PersonaOut(BaseModel):
    dni: str
    nombres: str = ""
    apellido_paterno: str = ""
    apellido_materno: str = ""
    found: bool = False
    offline: bool = False


class VisitaIn(BaseModel):
    dni: str = Field(..., pattern=r"^\d{8}$")
    tipo: str = Field(..., pattern=r"^(ENTRADA|SALIDA)$")
    nombres: str | None = None
    apellido_paterno: str | None = None
    apellido_materno: str | None = None


# ======================================================
# BD (reemplaza por tu acceso real)
# ======================================================
def db_get_persona(dni: str):
    # TODO: consulta tu BD y devuelve dict o None
    return None


def db_upsert_persona(dni: str, nombres: str, apellido_paterno: str, apellido_materno: str):
    # TODO: guarda/actualiza persona en tu BD
    return


def db_insert_visita(
    dni: str,
    tipo: str,
    nombres: str,
    apellido_paterno: str,
    apellido_materno: str,
    usuario: str | None,
):
    # TODO: inserta visita en tu BD
    return {
        "creado_en": datetime.now().isoformat(timespec="seconds"),
        "tipo": tipo,
        "dni": dni,
        "nombres": nombres,
        "apellido_paterno": apellido_paterno,
        "apellido_materno": apellido_materno,
        "usuario": usuario,
    }


def db_list_visitas(fecha: date, limit: int):
    # TODO: query por fecha
    return []


# ======================================================
# 1) Preview persona (BD -> Servicio externo)
# ======================================================
@router.get("/persona/{dni}", response_model=PersonaOut)
def get_persona(dni: str):
    dni = _only_digits(dni)
    if len(dni) != 8:
        raise HTTPException(status_code=400, detail="DNI inválido")

    # 1) BD
    p = db_get_persona(dni)
    if p:
        return PersonaOut(
            dni=dni,
            nombres=p.get("nombres", ""),
            apellido_paterno=p.get("apellido_paterno", ""),
            apellido_materno=p.get("apellido_materno", ""),
            found=True,
            offline=False,
        )

    # 2) Servicio externo
    try:
        raw = consultar_dni_fullname(dni)
        if not raw:
            return PersonaOut(dni=dni, found=False, offline=False)

        nombres, ap_pat, ap_mat = norm_persona_from_service(raw)

        if not nombres and not ap_pat and not ap_mat:
            return PersonaOut(dni=dni, found=False, offline=False)

        # cache en BD (internamente puedes manejar "fuente", pero no se expone)
        db_upsert_persona(dni, nombres, ap_pat, ap_mat)

        return PersonaOut(
            dni=dni,
            nombres=nombres,
            apellido_paterno=ap_pat,
            apellido_materno=ap_mat,
            found=True,
            offline=False,
        )

    except requests.RequestException:
        return PersonaOut(dni=dni, found=False, offline=True)


# ======================================================
# 2) Registrar visita
# ======================================================
@router.post("/visita")
def post_visita(payload: VisitaIn):
    dni = payload.dni

    # --- caso manual ---
    if payload.nombres and payload.apellido_paterno and payload.apellido_materno:
        nombres = payload.nombres.strip()
        ap_pat = payload.apellido_paterno.strip()
        ap_mat = payload.apellido_materno.strip()

        if not nombres or not ap_pat or not ap_mat:
            raise HTTPException(status_code=400, detail="Nombres/apellidos requeridos (manual).")

        db_upsert_persona(dni, nombres, ap_pat, ap_mat)
        return db_insert_visita(dni, payload.tipo, nombres, ap_pat, ap_mat, usuario=None)

    # --- caso automático ---
    p = db_get_persona(dni)
    if p:
        nombres = (p.get("nombres") or "").strip()
        ap_pat = (p.get("apellido_paterno") or "").strip()
        ap_mat = (p.get("apellido_materno") or "").strip()

        if not nombres or not ap_pat or not ap_mat:
            # si tu BD tiene parcial, fuerza consulta externa
            p = None

    if not p:
        raw = consultar_dni_fullname(dni)
        if not raw:
            raise HTTPException(status_code=404, detail="No encontrado en BD ni en servicio externo")

        nombres, ap_pat, ap_mat = norm_persona_from_service(raw)

        if not nombres or not ap_pat or not ap_mat:
            raise HTTPException(status_code=502, detail="Servicio externo devolvió datos incompletos")

        db_upsert_persona(dni, nombres, ap_pat, ap_mat)

    return db_insert_visita(dni, payload.tipo, nombres, ap_pat, ap_mat, usuario=None)


# ======================================================
# 3) Listar visitas
# ======================================================
@router.get("/visitas")
def list_visitas(
    fecha: date = Query(..., description="YYYY-MM-DD"),
    limit: int = Query(500, ge=1, le=500),
):
    return {"items": db_list_visitas(fecha, limit)}
